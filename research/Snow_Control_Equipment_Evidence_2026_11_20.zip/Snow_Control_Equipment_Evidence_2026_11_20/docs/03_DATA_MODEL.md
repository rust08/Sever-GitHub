# Схема доказательного каталога ресурсов

`Organization` ← `EquipmentAsset` ← `EquipmentConfiguration` (навески) ← `Capability`

`Source` → `EvidenceObservation` (дата, зона, сравнение, метод получения, степень подтверждения)

`EquipmentAsset` + `OperatorShift` + `VehicleStatus` + `ResourceMaterials` → `AvailabilitySnapshot`

`ConfirmedContract` + `Area×Operation` + `AvailabilitySnapshot` → `EligibleMachine` → `Planner`

## Строгие правила сопоставления
- `fleet_observation` **не** создаёт `equipment_asset` автоматически.
- `reported_readiness_count` нельзя читать как `available_units_count`.
- `tender_work_class` задаёт возможный **тип операции/расценки**, но не подтверждает машину.
- `historically_reported_operations` не подтверждают ни владение, ни актуальное право работы в зоне.
- `emergency_formation` — отдельный резерв/организационная таблица; требуется подтверждение реальной сменной готовности.
- `source_id`, дата публикации, дата события, зона и документ обязательны для факта.
- `unknown != 0` и `unknown != false`.
- **Не хранить ФИО водителей**, если задача решается обезличенными ID; соблюдать применимые требования к персональным данным.

## Основные поля машины
`asset_id_pseudonymous`, `operator_id`, `document_kind`, `source_document_id`, `verified_on`, `make`, `model`, `attachments`, `width`, `mass`, `dimensions`, `gross weight`, `axle loads`, `bucket volume`, `payload`, `salt hopper`, `working_speed_distribution`, `travel_speed_distribution`, `fuel consumption`, `maintenance intervals`, `crew availability`, `operating window`, `base_id`, `contract eligibility`.

## Интеграция с прошлым пакетом
`operator_id` использует те же ключи, что `Snow_Control_Territory_Responsibility_2026_11_20/data/operator_catalog_NOT_current_contracts.csv`, когда такой ключ существовал. Для ИП Кривенко добавлен новый ключ `IP_KRIVENKO` как исторический участник эпизода. Нужна юридическая идентификация по ЕГРЮЛ/ЕГРИП при реальной интеграции, чтобы названия-тёзки не сливались.

## Неизвестные параметры
`data/real_operational_parameters_UNKNOWN.json` хранит осмысленные `null` и пустые записи, а не выдуманные измерения.
`data/verified_machines_TEMPLATE_EMPTY.csv` — место для верифицированных ресурсов; документальных строк пока 0.
