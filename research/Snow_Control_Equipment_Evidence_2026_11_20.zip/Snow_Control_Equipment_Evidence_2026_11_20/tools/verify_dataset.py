#!/usr/bin/env python3
"""Integrity checks of public evidence; not a legal or physical fleet audit."""
from pathlib import Path
import argparse,json,csv,datetime

def check(root):
    root=Path(root)
    sources=json.loads((root/'data/sources.json').read_text(encoding='utf-8'))
    facts=json.loads((root/'data/evidence.json').read_text(encoding='utf-8'))
    orgs=json.loads((root/'data/organizations_historical_capabilities.json').read_text(encoding='utf-8'))
    unknown=json.loads((root/'data/real_operational_parameters_UNKNOWN.json').read_text(encoding='utf-8'))
    ids={s['id'] for s in sources}
    assert len(ids)==len(sources)
    assert all(s['url'].startswith('https://') for s in sources)
    assert all(s['observed_date']<='2026-11-20' for s in facts)
    assert all(f['source_id'] in ids for f in facts)
    assert len({f['id'] for f in facts})==len(facts)
    assert all(f['usable_as_active_fleet'] is False for f in facts)
    assert all(o['source_id'] in ids for o in orgs)
    assert all(o['has_verified_current_fleet'] is False for o in orgs)
    assert all(o['owns_listed_machines']=='unknown' for o in orgs)
    assert unknown['citywide_active_fleet'] is None
    assert not unknown['verified_working_speeds_kmh']
    assert not unknown['verified_travel_speeds_kmh']
    with (root/'data/verified_machines_TEMPLATE_EMPTY.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.DictReader(f))
    assert len(rows)==0, 'User-verified asset rows were expected to be empty in supplied research'
    city=[x for x in facts if x['field']=='reported_ready_vehicles']; assert len(city)==1 and city[0]['value']==185 and city[0]['kind']=='readiness_count'
    night=[x for x in facts if x['field']=='vehicles_working_night'];assert len(night)==3
    assert any(x['qualifier']=='approximately' for x in night)
    assert any(x['qualifier']=='greater_than' for x in night)
    assert all(x['kind']!='physical_vehicle_verified' for x in facts)
    return {'sources':len(sources),'facts':len(facts),'operators':len(orgs),'verified_individual_machines':0,'verified_real_speeds':0,'status':'PASS'}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',default='.'); a=ap.parse_args();print(json.dumps(check(a.root),ensure_ascii=False,indent=2))
