#!/usr/bin/env python3
"""Export research context but intentionally NO individual machine list or speed assumptions."""
from pathlib import Path
import argparse,json
from verify_dataset import check

def export(root):
 root=Path(root); check(root)
 facts=json.loads((root/'data/evidence.json').read_text(encoding='utf-8'))
 operators=json.loads((root/'data/organizations_historical_capabilities.json').read_text(encoding='utf-8'))
 return {'schema_version':'1.0','as_of':'2026-11-20','confidence_warning':'PUBLIC EVIDENCE ONLY; NOT ACTUAL FLEET INVENTORY','reported_observations':facts,'historical_operators':operators,'physical_vehicle_assets':[],'verified_real_vehicle_speeds':{},'allowed_real_planning':False,'reason':'insufficient_evidence_to_infer_vehicle_availability_and_speed'}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--root',default='.');ap.add_argument('--out',default='outputs/safe_codex_context.json');a=ap.parse_args();p=Path(a.root)/a.out;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(export(a.root),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(p)
