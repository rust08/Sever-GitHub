from pathlib import Path
import sys,unittest,json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from verify_dataset import check
from export_safe_context import export
class EvidenceTests(unittest.TestCase):
 def setUp(self):
  self.ctx=export(ROOT)
  self.facts=self.ctx['reported_observations']
 def test_integrity(self):self.assertEqual(check(ROOT)['status'],'PASS')
 def test_no_invented_assets(self):self.assertEqual(self.ctx['physical_vehicle_assets'],[])
 def test_no_invented_work_speed(self):self.assertEqual(self.ctx['verified_real_vehicle_speeds'],{})
 def test_real_planning_blocked(self):self.assertIs(self.ctx['allowed_real_planning'],False)
 def test_readiness_not_active(self):
  f=next(x for x in self.facts if x['field']=='reported_ready_vehicles')
  self.assertEqual(f['value'],185);self.assertEqual(f['scope'],'citywide');self.assertEqual(f['kind'],'readiness_count');self.assertFalse(f['usable_as_active_fleet'])
 def test_receipt_vs_order(self):
  d=next(x for x in self.facts if x['field']=='new_machines_delivered_by_2026_09_25')
  o=next(x for x in self.facts if x['field']=='new_machines_reported_purchased')
  self.assertEqual((d['value'],o['value']),(10,28));self.assertNotEqual(d['field'],o['field'])
 def test_night_observation_semantics(self):
  f=[x for x in self.facts if x['field']=='vehicles_working_night'];self.assertEqual(len(f),3)
  self.assertEqual({(x['observed_date'],x['qualifier']) for x in f},{('2026-02-16','approximately'),('2026-02-18','greater_than'),('2026-03-03','reported_exact')})
 def test_emergency_separate_scope(self):
  f=[x for x in self.facts if x['kind']=='emergency_reserve'];self.assertEqual(len(f),4)
  self.assertTrue(all(x['scope']=='emergency_formation' and not x['usable_as_active_fleet'] for x in f))
 def test_historical_operator_not_contract(self):
  self.assertTrue(all(not o['has_verified_current_fleet'] and not o['has_verified_current_contract'] for o in self.ctx['historical_operators']))
 def test_historical_operator_not_ownership(self):
  self.assertTrue(all(o['owns_listed_machines']=='unknown' for o in self.ctx['historical_operators']))
 def test_nonwinter_vacuums_not_winter_fleet(self):
  f=next(x for x in self.facts if x['field']=='compact_street_vacuum_sweepers_reported')
  self.assertIn('НЕ зимние',f['comment']);self.assertFalse(f['usable_as_active_fleet'])
 def test_sites_do_not_gain_geolocation(self):
  self.assertTrue(any(x['field']=='reported_snow_storage_sites' and x['value']==3 for x in self.facts))
  self.assertNotIn('snow_site_coordinates',self.ctx)
if __name__=='__main__':unittest.main()
