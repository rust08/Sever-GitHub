import unittest,sys
from pathlib import Path
from datetime import date
sys.path.insert(0,str(Path(__file__).parents[1]/'tools'))
from assign_responsibility import run,verify_row
from match_historical_streets import canonical,match

NETWORK={'edges':[{'id':'edgeA','name':'улица А','geometry':[[158.5,53.0],[158.6,53.1]],'km':1.0,'highway':'residential'}, {'id':'edgeB','name':'улица Б','geometry':[[158.5,53.0],[158.4,53.1]],'km':1.0,'highway':'residential'}]}
BASE={'network_edge_id':'edgeA','operation':'plow','operator_id':'firm1','customer_id':'city','eis_contract_number':'99','eis_contract_url':'https://zakupki.gov.ru/epz/contract/contractCard/common-info.html?reestrNumber=99','scope_attachment_id':'appendix_1','scope_page_or_clause':'p2','valid_from':'2026-10-01','valid_to':'2027-01-31','contract_status':'active','verification_status':'verified_against_signed_contract','reviewer':'test_reviewer','reviewed_at':'2026-11-19'}

class PipelineTests(unittest.TestCase):
    def test_empty_has_zero_verified(self):
        _,_,stats=run(NETWORK,[],date(2026,11,20),'plow');self.assertEqual(stats['status_counts'],{'unverified':2})
    def test_valid_explicit_contract_one_edge(self):
        _,_,stats=run(NETWORK,[BASE.copy()],date(2026,11,20),'plow');self.assertEqual(stats['status_counts']['verified'],1)
    def test_press_report_not_contract(self):
        r={**BASE,'verification_status':'reported_by_media'}
        _,review,stats=run(NETWORK,[r],date(2026,11,20),'plow')
        self.assertEqual(stats['status_counts']['unverified'],2)
        self.assertEqual(review[0]['validation'],'not_signed_contract_verified')
    def test_expired_contract_rejected(self):
        r={**BASE,'valid_to':'2026-11-01'}
        _,review,stats=run(NETWORK,[r],date(2026,11,20),'plow');self.assertEqual(review[0]['validation'],'outside_active_dates')
    def test_conflicting_contract_rows_never_autoresolve(self):
        a=BASE.copy();b={**BASE,'operator_id':'firm2','eis_contract_number':'100'}
        geo,_,stats=run(NETWORK,[a,b],date(2026,11,20),'plow');self.assertEqual(stats['status_counts']['conflict'],1);self.assertIsNone(geo['features'][0]['properties']['operator_id'])
    def test_only_matching_operation(self):
        r={**BASE,'operation':'anti_ice'}
        _,_,stats=run(NETWORK,[r],date(2026,11,20),'plow');self.assertEqual(stats['status_counts']['unverified'],2)
    def test_nonofficial_contract_url_rejected(self):
        r={**BASE,'eis_contract_url':'https://some-news-site.example/work'}
        _,review,_=run(NETWORK,[r],date(2026,11,20),'plow');self.assertEqual(review[0]['validation'],'no_official_EIS_contract_reference')
    def test_unknown_edge_rejected(self):
        r={**BASE,'network_edge_id':'missing'}
        _,review,_=run(NETWORK,[r],date(2026,11,20),'plow');self.assertEqual(review[0]['validation'],'unknown_edge_id')
    def test_name_match_stays_unverified(self):
        hist=[{'street_name':'ул А','operator_id':'firm1','operation':'plow','event_date':'2026-02-12','source_url':'https://example.org'}]
        # normalizer has no alias for "ул А" vs "улица А"? Both must match
        candidates=match(NETWORK,hist);self.assertEqual(len(candidates),1)
        self.assertEqual(candidates[0]['current_assignment'],'DO_NOT_INFER')

if __name__=='__main__':unittest.main()
