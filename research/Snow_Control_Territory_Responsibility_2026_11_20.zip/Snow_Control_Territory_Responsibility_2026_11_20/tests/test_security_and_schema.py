import sys,sqlite3,unittest
from pathlib import Path
from datetime import date
sys.path.insert(0,str(Path(__file__).parents[1]/'tools'))
from assign_responsibility import verify_row
BASE={'network_edge_id':'e1','operation':'plow','operator_id':'firm','customer_id':'city','eis_contract_number':'1','eis_contract_url':'https://zakupki.gov.ru/epz/contract','scope_attachment_id':'1','scope_page_or_clause':'p5','valid_from':'2026-11-01','valid_to':'2027-03-01','contract_status':'active','verification_status':'verified_against_signed_contract','reviewer':'tester','reviewed_at':'2026-11-20'}
class SecurityAndSchema(unittest.TestCase):
 def test_url_spoofing_is_not_official_eis(self):
  r={**BASE,'eis_contract_url':'https://zakupki.gov.ru.evil.example/contract'}
  self.assertEqual(verify_row(r,{'e1'},date(2026,11,20),'plow'),'no_official_EIS_contract_reference')
 def test_sqlite_migration_is_valid(self):
  sql=(Path(__file__).parents[1]/'sql/001_responsibility_schema.sql').read_text(encoding='utf-8')
  with sqlite3.connect(':memory:') as db:
   db.executescript(sql)
   names={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
   self.assertIn('responsibility_assignments',names)
 def test_valid_contract_not_automatic_for_different_operation(self):
  self.assertEqual(verify_row(BASE,{'e1'},date(2026,11,20),'anti_ice'),'other_operation')
if __name__=='__main__':unittest.main()
