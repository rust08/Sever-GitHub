#!/usr/bin/env python3
"""Download raw OSM XML from Overpass. Requires internet. Only geometry, NOT legal responsibility.
BBox format: south,west,north,east. e.g. --bbox='53.01,158.60,53.10,158.70' is merely a demo window, NOT the municipality outline.
Output must be reviewed for completeness. Respect Overpass server limits and ODbL attribution.
"""
import argparse,urllib.parse,urllib.request
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__)
 group=p.add_mutually_exclusive_group(required=True)
 group.add_argument('--bbox',help='south,west,north,east (degrees) - user verified extent')
 group.add_argument('--area-name',help='Exact OSM administrative area name, may not uniquely resolve')
 p.add_argument('--out',required=True)
 p.add_argument('--endpoint',default='https://overpass.kumi.systems/api/interpreter')
 p.add_argument('--timeout',type=int,default=180)
 a=p.parse_args()
 if a.bbox:
  b=[float(x) for x in a.bbox.split(',')]; assert len(b)==4 and b[0]<b[2] and b[1]<b[3]
  assert (b[2]-b[0])*(b[3]-b[1])<0.12,'Split this bounding box into smaller tiles'
  selector='(' + ','.join(f'{x:.7f}' for x in b) + ')'
  q=f'[out:xml][timeout:{a.timeout}];way["highway"]{selector};(._;>;);out body;'
 else:
  # Generic OSM administrative area; this can be absent or ambiguous.
  name=a.area_name.replace('"','\\"')
  q=f'[out:xml][timeout:{a.timeout}];area["boundary"="administrative"]["name"="{name}"]->.searchArea;way["highway"](area.searchArea);(._;>;);out body;'
 payload=urllib.parse.urlencode({'data':q}).encode()
 req=urllib.request.Request(a.endpoint,data=payload,headers={'User-Agent':'SnowControlResearchPrototype/0.1 (OSM attribution required)','Content-Type':'application/x-www-form-urlencoded'})
 try:
  with urllib.request.urlopen(req,timeout=a.timeout+30) as r: content=r.read()
 except Exception as exc:raise SystemExit(f'Overpass unavailable / throttled / query too big: {exc}')
 if not content.lstrip().startswith(b'<?xml') and not content.lstrip().startswith(b'<osm'):
  raise SystemExit(f'Unexpected response (first bytes): {content[:250]!r}')
 out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(content)
 print(f'Saved {len(content)} bytes OSM XML to {out}. Verify city limits; OSM is not a legal road or contractor registry.')

if __name__=='__main__':main()
