#!/usr/bin/env python3
"""Generate suggestions from past dated street reports. NEVER exports verified assignments.
Usage: python tools/match_historical_streets.py --network data/road_graph_original_pilot.json --historical data/historical_street_name_evidence.csv --out build/historical_candidates.csv
"""
import argparse,csv,json,re,unicodedata
from collections import defaultdict
from pathlib import Path

def canonical(name):
    s=(name or '').lower().replace('ё','е').replace('–','-')
    s=re.sub(r'[^а-я0-9\- ]',' ',s)
    s=re.sub(r'\b(улица|ул|проспект|пр|переулок|пер|площадь|пл)\b',' ',s)
    return re.sub(r'\s+',' ',s).strip()

def match(network, historical):
    names=defaultdict(list)
    for e in network['edges']:
        nm=canonical(e.get('name'))
        if nm and nm not in ('проезд без названия',):names[nm].append(e)
    out=[]
    for h in historical:
        for e in names.get(canonical(h['street_name']),[]):
            out.append({'edge_id':e['id'],'road_name_osm':e['name'],'source_name':h['street_name'],'operator_in_historical_report':h['operator_id'],'reported_operation':h['operation'],'event_date':h['event_date'],'source_url':h['source_url'],'MATCH_TYPE':'EXACT_NORMALIZED_STREET_NAME_ONLY','contract_status':'UNKNOWN','current_assignment':'DO_NOT_INFER','review_needed':'Street names can cover many segments and several contractors.'})
    return out

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--network',default='data/road_graph_original_pilot.json')
    p.add_argument('--historical',default='data/historical_street_name_evidence.csv')
    p.add_argument('--out',default='build/historical_candidates.csv')
    a=p.parse_args();net=json.loads(Path(a.network).read_text(encoding='utf8'))
    with open(a.historical,encoding='utf-8-sig',newline='') as f:hist=list(csv.DictReader(f))
    rows=match(net,hist);out=Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
    keys=['edge_id','road_name_osm','source_name','operator_in_historical_report','reported_operation','event_date','source_url','MATCH_TYPE','contract_status','current_assignment','review_needed']
    with out.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
    print(f'Found {len(rows)} unverified historical street-name candidate pairs (NOT assignments).')

if __name__=='__main__':main()
