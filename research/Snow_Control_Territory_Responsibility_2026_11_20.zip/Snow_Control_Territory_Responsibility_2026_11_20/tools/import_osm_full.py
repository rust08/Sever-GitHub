#!/usr/bin/env python3
"""OSM XML -> graph. Retains disconnected edges (unlike Snow Control's prototype importer).
No depot assigned; no assumption that all ways are public roads. For city use, verify boundary,
access/turn restrictions, split ways at contract scope boundaries, IDs and road ownership.
"""
import argparse,json,math,xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
from datetime import datetime,timezone

CLASSES={'trunk','trunk_link','primary','primary_link','secondary','secondary_link','tertiary','tertiary_link','residential','living_street','service','unclassified','road'}
def hav(p,q):
 a=math.radians(p[1]);b=math.radians(q[1]);lat=b-a;lon=math.radians(q[0]-p[0]);t=math.sin(lat/2)**2+math.cos(a)*math.cos(b)*math.sin(lon/2)**2
 return 12742*2*math.asin(min(1,math.sqrt(t)))
def build(path):
 tree=ET.parse(path).getroot()
 nodes={n.get('id'):[float(n.get('lon')),float(n.get('lat'))] for n in tree.findall('node') if n.get('lon') and n.get('lat')}
 ways=[];count=Counter()
 for way in tree.findall('way'):
  tags={t.get('k'):t.get('v') for t in way.findall('tag')}
  if tags.get('highway') not in CLASSES or tags.get('area')=='yes':continue
  seq=[n.get('ref') for n in way.findall('nd')]
  # Only keep complete ways. Incomplete network must not silently omit nodes.
  if len(seq)<2 or any(r not in nodes for r in seq):continue
  ways.append((way.get('id'),tags,seq));count.update(seq)
 edges=[]
 for way_id,tags,seq in ways:
  oneway=tags.get('oneway','yes' if tags.get('junction')=='roundabout' else 'no')
  if oneway not in {'yes','no','true','false','1','0','-1'}:continue
  cuts=[0]+[i for i in range(1,len(seq)-1) if count[seq[i]]>1]+[len(seq)-1]
  for begin,end in zip(cuts,cuts[1:]):
   section=seq[begin:end+1]
   if section[0]==section[-1]:continue
   if oneway=='-1':section=list(reversed(section))
   geom=[nodes[k] for k in section]
   km=sum(hav(a,b) for a,b in zip(geom,geom[1:]))
   if km<=0:continue
   edges.append({'id':f'w{way_id}-{section[0]}-{section[-1]}','osmWay':way_id,'from':section[0],'to':section[-1],'geometry':geom,'km':round(km,5),'oneway':oneway in {'yes','true','1','-1'},'highway':tags['highway'],'name':tags.get('name','Проезд без названия'),'access':tags.get('access'),'motor_vehicle':tags.get('motor_vehicle'),'service':tags.get('service'),'surface':tags.get('surface'),'bridge':tags.get('bridge'),'road_owner':'UNKNOWN','contractor':'UNKNOWN'})
 used={k for e in edges for k in (e['from'],e['to'])}
 return {'nodes':{n:nodes[n] for n in sorted(used)},'edges':edges,'depot':None,'source':str(path),'attribution':'© OpenStreetMap contributors','license':'https://www.openstreetmap.org/copyright','generatedUtc':datetime.now(timezone.utc).isoformat(),'coverage_verified':False,'legal_classification_verified':False,'warning':'OSM does not establish road ownership, legal responsibility, contract coverage, or driveable turns'}
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('input_xml');p.add_argument('output_json');a=p.parse_args()
 d=build(a.input_xml);out=Path(a.output_json);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(d,ensure_ascii=False,indent=1),encoding='utf8')
 print(f"{len(d['nodes'])} graph nodes, {len(d['edges'])} road sections (not a legally verified road registry)")
if __name__=='__main__':main()
