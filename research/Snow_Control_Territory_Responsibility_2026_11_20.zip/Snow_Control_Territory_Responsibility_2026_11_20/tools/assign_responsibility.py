#!/usr/bin/env python3
"""Strict contract-to-OSM-edge join. Stdlib only; NEVER accepts press reports as authority.
Usage: python tools/assign_responsibility.py --network data/road_graph_original_pilot.json --assignments data/verified_contract_assignments_FILL_MANUALLY.csv --as-of 2026-11-20 --operation plow --out build
"""
from __future__ import annotations
import argparse, csv, json
from collections import defaultdict, Counter
from datetime import date
from pathlib import Path
from urllib.parse import urlparse

OPS={'plow','anti_ice','load_snow','haul_snow','sidewalk_clear','manual_clear','snowbank_remove','all'}
MANDATORY=('network_edge_id','operator_id','eis_contract_number','eis_contract_url','scope_attachment_id','scope_page_or_clause','valid_from','valid_to','reviewer','reviewed_at','customer_id')

def load_csv(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as f: return list(csv.DictReader(f))

def verify_row(row, edge_ids, as_of, operation):
    if row.get('operation') not in OPS: return 'invalid_operation'
    if row.get('operation') not in (operation,'all'): return 'other_operation'
    if row.get('network_edge_id') not in edge_ids: return 'unknown_edge_id'
    if row.get('verification_status')!='verified_against_signed_contract': return 'not_signed_contract_verified'
    if row.get('contract_status')!='active': return 'contract_not_confirmed_active'
    missing=[f for f in MANDATORY if not str(row.get(f,'')).strip()]
    if missing: return 'missing:'+','.join(missing)
    if urlparse(row['eis_contract_url']).scheme != 'https' or urlparse(row['eis_contract_url']).hostname not in ('zakupki.gov.ru','www.zakupki.gov.ru'): return 'no_official_EIS_contract_reference'
    try:
        lo=date.fromisoformat(row['valid_from']);hi=date.fromisoformat(row['valid_to'])
        date.fromisoformat(row['reviewed_at'])
    except ValueError:return 'invalid_dates'
    if hi < lo:return 'invalid_date_interval'
    if not (lo <= as_of <= hi):return 'outside_active_dates'
    return 'eligible'

def run(network,assignments,as_of,operation):
    assert operation in OPS - {'all'},'Choose a specific operation, not all'
    edge_ids={x['id'] for x in network['edges']}
    found=defaultdict(list);review=[]
    for n,row in enumerate(assignments, start=2):
        result=verify_row(row,edge_ids,as_of,operation)
        review.append({'csv_line':n,'edge_id':row.get('network_edge_id',''),'operation':row.get('operation',''),'operator_id':row.get('operator_id',''),'validation':result})
        if result=='eligible':found[row['network_edge_id']].append(row)
    features=[]; counts=Counter()
    for edge in network['edges']:
        matches=found[edge['id']]; contractors={ (m['operator_id'],m['eis_contract_number']) for m in matches}
        if not matches: status='unverified'; org=None; contract=None
        elif len(contractors)>1:status='conflict';org=None;contract=None
        else:status='verified';org=matches[0]['operator_id'];contract=matches[0]['eis_contract_number']
        counts[status]+=1
        features.append({'type':'Feature','id':edge['id'], 'geometry':{'type':'LineString','coordinates':edge['geometry']},'properties':{'edge_id':edge['id'],'name':edge.get('name'),'highway':edge.get('highway'),'km':edge['km'],'operation':operation,'responsibility_status':status,'operator_id':org,'contract_id':contract,'candidate_count':len(matches),'osm_way':edge.get('osmWay')}})
    stats={'date':as_of.isoformat(),'operation':operation,'total_edges':len(features),'status_counts':dict(counts),'input_rows':len(assignments),'accepted_rows':sum(r['validation']=='eligible' for r in review),'warning':'No spatial or news-based inference is permitted. No legal assertion on unverified edges. Original OSM graph only.'}
    return {'type':'FeatureCollection','properties':stats,'features':features},review,stats

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--network',default='data/road_graph_original_pilot.json')
    p.add_argument('--assignments',default='data/verified_contract_assignments_FILL_MANUALLY.csv')
    p.add_argument('--as-of',default='2026-11-20')
    p.add_argument('--operation',default='plow',choices=sorted(OPS-{'all'}))
    p.add_argument('--out',default='build')
    a=p.parse_args()
    d=json.loads(Path(a.network).read_text(encoding='utf-8'))
    geo,review,stats=run(d,load_csv(a.assignments),date.fromisoformat(a.as_of),a.operation)
    out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
    (out/f'roads_{a.operation}_{a.as_of}.geojson').write_text(json.dumps(geo,ensure_ascii=False),encoding='utf8')
    (out/f'coverage_{a.operation}_{a.as_of}.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf8')
    with (out/'assignment_review.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['csv_line','edge_id','operation','operator_id','validation']);w.writeheader();w.writerows(review)
    print(json.dumps(stats,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
