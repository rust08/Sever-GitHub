-- Proposed SQLite schema for Snow Control responsibility layer. NOT applied to user project.
-- WARNING: only contract-signed reviewed sources can produce verified responsible assignments.
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS responsibility_organizations (
  org_id TEXT PRIMARY KEY,
  legal_name TEXT NOT NULL,
  org_kind TEXT NOT NULL,
  inn TEXT,
  identity_registry_verified INTEGER NOT NULL DEFAULT 0 CHECK (identity_registry_verified IN (0,1))
);
CREATE TABLE IF NOT EXISTS responsibility_source_documents (
  source_id TEXT PRIMARY KEY,
  source_type TEXT NOT NULL,
  original_url TEXT NOT NULL,
  document_sha256 TEXT,
  publication_date TEXT,
  retrieved_at TEXT,
  provenance_notes TEXT
);
CREATE TABLE IF NOT EXISTS responsibility_assets (
  asset_id TEXT PRIMARY KEY,
  routing_edge_id TEXT,
  osm_way_id TEXT,
  asset_kind TEXT NOT NULL,
  road_ownership_level TEXT NOT NULL DEFAULT 'unknown',
  official_road_register_id TEXT,
  geometry_geojson TEXT,
  boundary_confirmed INTEGER NOT NULL DEFAULT 0 CHECK (boundary_confirmed IN (0,1))
);
CREATE TABLE IF NOT EXISTS responsibility_contracts (
  contract_register_id TEXT PRIMARY KEY,
  notice_number TEXT,
  customer_org_id TEXT,
  prime_contractor_org_id TEXT,
  signed_contract_source_id TEXT,
  status TEXT NOT NULL DEFAULT 'unverified',
  effective_from TEXT,
  effective_to TEXT,
  last_checked TEXT,
  FOREIGN KEY (customer_org_id) REFERENCES responsibility_organizations(org_id),
  FOREIGN KEY (prime_contractor_org_id) REFERENCES responsibility_organizations(org_id),
  FOREIGN KEY (signed_contract_source_id) REFERENCES responsibility_source_documents(source_id)
);
CREATE TABLE IF NOT EXISTS responsibility_scopes (
  scope_id TEXT PRIMARY KEY,
  contract_register_id TEXT NOT NULL,
  asset_id TEXT,
  operation TEXT NOT NULL,
  geographic_description TEXT,
  source_document_id TEXT NOT NULL,
  source_page_or_clause TEXT,
  valid_from TEXT,
  valid_to TEXT,
  match_status TEXT NOT NULL DEFAULT 'unreviewed',
  reviewer TEXT,
  reviewed_at TEXT,
  FOREIGN KEY (contract_register_id) REFERENCES responsibility_contracts(contract_register_id),
  FOREIGN KEY (asset_id) REFERENCES responsibility_assets(asset_id),
  FOREIGN KEY (source_document_id) REFERENCES responsibility_source_documents(source_id)
);
CREATE TABLE IF NOT EXISTS responsibility_assignments (
  assignment_id TEXT PRIMARY KEY,
  scope_id TEXT NOT NULL,
  asset_id TEXT NOT NULL,
  operation TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'prime_contractor',
  assigned_org_id TEXT NOT NULL,
  valid_from TEXT NOT NULL,
  valid_to TEXT NOT NULL,
  verification_status TEXT NOT NULL DEFAULT 'unverified' CHECK (verification_status IN ('unverified','verified_against_signed_contract','conflict','expired','revoked')),
  reviewer TEXT,
  reviewed_at TEXT,
  FOREIGN KEY (scope_id) REFERENCES responsibility_scopes(scope_id),
  FOREIGN KEY (asset_id) REFERENCES responsibility_assets(asset_id),
  FOREIGN KEY (assigned_org_id) REFERENCES responsibility_organizations(org_id)
);
CREATE INDEX IF NOT EXISTS responsibility_by_asset_operation_date ON responsibility_assignments(asset_id,operation,valid_from,valid_to);
CREATE INDEX IF NOT EXISTS responsibility_by_contract_status ON responsibility_contracts(status,effective_from,effective_to);
-- Operational evidence is separate from contractual responsibility.
CREATE TABLE IF NOT EXISTS responsibility_work_evidence (
  evidence_id TEXT PRIMARY KEY,
  asset_id TEXT,
  executor_org_id TEXT,
  operation TEXT,
  worked_at TEXT,
  source_id TEXT,
  work_order_id TEXT,
  acceptance_status TEXT NOT NULL DEFAULT 'unverified',
  FOREIGN KEY (asset_id) REFERENCES responsibility_assets(asset_id),
  FOREIGN KEY (executor_org_id) REFERENCES responsibility_organizations(org_id),
  FOREIGN KEY (source_id) REFERENCES responsibility_source_documents(source_id)
);
