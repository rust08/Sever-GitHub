#!/usr/bin/env python3
"""Static consistency validation for Snow Control governance research (not a legal verification)."""
import csv
import json
import pathlib
import re

ROOT = pathlib.Path(__file__).resolve().parent.parent
REQ = ROOT / '03_REQUIREMENTS_MATRIX.csv'
SCEN = ROOT / '04_ACCEPTANCE_SCENARIOS.json'
SRC = ROOT / '05_SOURCE_REGISTER.md'
files = [f'{i:02d}_{n}.md' for i, n in []]
required = [
    '00_START_HERE_CODEX.md', '01_GOVERNANCE_LEGAL_RESEARCH.md', '02_ENGINEERING_SPEC.md',
    '03_REQUIREMENTS_MATRIX.csv', '04_ACCEPTANCE_SCENARIOS.json', '05_SOURCE_REGISTER.md',
    '06_STAKEHOLDER_INTERVIEWS.md', '07_PRODUCT_ROADMAP.md', '08_FOR_OWNER_BRIEF.md',
    '09_PROCUREMENT_CASE_STUDY.md', '10_PACKAGE_README.md',
    'tests/planner.audit.test.mjs', 'tests/BASELINE_OUTPUT.txt',
]
for p in required:
    assert (ROOT / p).is_file(), f'Missing: {p}'
with REQ.open(encoding='utf-8-sig', newline='') as f:
    rows = list(csv.DictReader(f, delimiter=';'))
assert len(rows) == 42, f'Expected 42 requirements, got {len(rows)}'
req_ids = {r['id'] for r in rows}
assert len(req_ids) == len(rows), 'Duplicate requirement ID'
assert all(set(r) == {'id', 'domain', 'priority', 'requirement', 'sources', 'evidence_status', 'data_needed', 'acceptance_criterion', 'signoff_role'} for r in rows)
assert all(r['priority'] in {'P0', 'P1', 'P2'} for r in rows)
source_text = SRC.read_text(encoding='utf-8')
source_ids = set(re.findall(r'^\|\s*(S\d+)\s*\|', source_text, re.MULTILINE))
assert len(source_ids) == 43, f'Expected 43 sources, got {len(source_ids)}'
for row in rows:
    if row['sources'] != 'none':
        for s in row['sources'].split(';'):
            assert s in source_ids, f'Requirement {row["id"]} uses missing source {s}'
scenarios = json.loads(SCEN.read_text(encoding='utf-8'))['scenarios']
assert len(scenarios) == 35, f'Expected 35 scenarios, got {len(scenarios)}'
scenario_ids = set()
for scenario in scenarios:
    assert not scenario['executable'], f'{scenario["id"]} inaccurately claims executable'
    assert scenario['id'] not in scenario_ids, 'Duplicate scenario ID'
    scenario_ids.add(scenario['id'])
    for rid in scenario['requirement_ids']:
        assert rid in req_ids, f'{scenario["id"]} has missing requirement {rid}'
print(f'PASS: {len(rows)} requirements; {len(scenarios)} scenarios; {len(source_ids)} source references; {len(required)} required files.')
print('NOTE: Does not check the current law, factual accuracy, coverage of contracts, or algorithm correctness.')
