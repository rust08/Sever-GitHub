# Snow Control — инженерная спецификация на основе правового и управленческого аудита

**Назначение:** техническое задание для Codex поверх существующего проекта `snow-control`. **Срез:** 2026-11-20. **Важный принцип:** нижеследующее — предлагаемые системные требования/архитектура; это не утверждение о юридических обязанностях конкретной организации. Юридические нормы и статус подтверждения см. `01_GOVERNANCE_LEGAL_RESEARCH.md`, `05_SOURCE_REGISTER.md`.

## 1. Сформулировать новую задачу продукта

От `plan(roadEdges, vehicles)` перейти к `buildOperationalPlan(assets, workOrders, resources, authorities, contracts, rules, observations, horizon)`.

Результат состоит из трех независимых слоёв:
- **SERVICE STATE**: какой результат нужен на объекте, чего не хватает, качество и безопасность состояния (факт, прогноз или неизвестно).
- **OPERATION PLAN**: какие технологические действия, какая техника, где, когда и в какой последовательности.
- **LEGAL/AUDIT STATE**: кто имеет право поручить, кто исполняет, к какому договору и нормативу относится, что подтверждено и кем принято.

Нельзя выводить `legally_compliant=true` только из отрисованных маршрутов или пересечения GPS-трека с ребром.

## 2. Концептуальная схема данных

### 2.1. Asset (объект, а не всегда ребро)

```
Asset {
 id, kind: road_carriageway | lane | sidewalk | stop | stairway | crossing |
           driveway | courtyard | bridge | drainage | hydrant | parking | snow_site,
 geometry, roadGraphRefs[], officialAssetRegistryId?, cadastralId?, roadLegalClass?,
 streetGroup?, region?, municipality?, slope?, widthM?, lanes?,
 ownership: {organizationId?, basisDocumentId?, verifiedAt?, status},
 balanceHolder: {organizationId?, basisDocumentId?, verifiedAt?, status},
 operationResponsible: [{workType, organizationId, territory, validFrom, validTo,
                         basisDocumentId, status}],
 attributes: {emergencyAccessCritical?, publicTransitCritical?, floodRisk?, avalancheRisk?},
 evidenceRefs[], validTime, sourceQuality
}
```

`roadLegalClass` / `streetGroup` — **не** прямое преобразование OSM `highway`. Если официальной категории нет, `null` и `unverified`, а не P2 по умолчанию. Одна геометрия может иметь несколько сервисных объектов (проезжая часть, тротуар, остановка, ливневка) с разной подведомственностью.

### 2.2. Organization + Contract + Responsibility

```
Organization {id, legalName, ogrn?, type: authority | municipalInstitution | MUP |
              commercial | HOA | managementCompany | stateInstitution | other}
Contract {id, regime: FZ44 | FZ223 | private | municipalAssignment | other,
          customerId, contractorId, agreementUrl?, status,
          startAt, endAt, territoryAssetIds[], operationTypes[],
          unitPrices[], unitMeasures[], volumeLimits[], callOffRules?,
          serviceLevels[], inspectionRules?, fundingSourceId?,
          fundingLimit?, amendments[], legalEvidenceStatus}
Responsibility {assetId, operationType, responsibleOrganizationId,
                responsibleRole, basisDocument, effectiveFrom, effectiveUntil,
                confidence: verified | unverified | disputed}
```

Модель должна отличать владелец/балансодержатель, орган, формирующий задания, заказчик и исполнитель. Действия вне договора не объявлять допустимыми только потому, что у машины свободная смена. Межорганизационную помощь показывать как проект согласования.

### 2.3. RuleRegistry — правила, у которых есть источник, объект и событие запуска часов

```
Rule {
 id, type: FEDERAL_STANDARD | MUNICIPAL_RULE | CONTRACT_SLA | EMERGENCY_ORDER |
           INTERNAL_TARGET | USER_DEFINED_SIMULATION,
 authority, identifier, articleOrClause, sourceUrl, revisionDate, validFrom, validUntil,
 applicability: {assetTypes[], territory?, roadClass?, streetGroup?,
                 operationTypes[], conditions[]},
 clockStartEvent: snowfall_end | slippery_detected | dispatch_order_issued |
                  work_accepted | fixed_time_of_day | condition_observed | other,
 clockDurationMinutes?, completionEvidenceType, exceptions?,
 verificationStatus: verified | source_outdated | needs_legal_review | draft,
 verifiedBy?, verifiedAt?, sourceSnapshotHash?
}
```

Особенно: текущие P1–P4 из `backend/policy.mjs` хранятся как `USER_DEFINED_SIMULATION`, **не** как ГОСТ. Для одного участка может действовать несколько требований: обеспечен проезд, остановка очищена, вал разорван, снег вывезен; завершения и часы у них различны.

### 2.4. Operations and ServiceRequirement

```
Operation {
 id, assetId, workType: anti_icing | patrol_plow | full_width_clear |
 berm_cut | sidewalk_clear | stairs_clear | stop_clear | ice_remove |
 snow_load | snow_haul | snow_unload | drainage_clear | inspect,
 parentRequirementId, precedenceIds[], canParallelWith[], requestedBy,
 contractId?, authorizedExecutorIds[], status, plannedStart, plannedEnd,
 observedStart?, observedEnd?, forecastVolumeM3?, verifiedVolumeM3?,
 requiredMachineCapabilities[], materialNeeds[], priorityJustification?,
 deadline: {ruleId?, originEventId?, at?, status: verified | assumed | unknown},
 resultEvidenceIds[], qualityStatus
}
ServiceRequirement {id, assetId, desiredCondition, evidenceSource, applicableRuleIds[],
 targetAt?, expiryAt?, priority, beneficiaryGroups[], status}
```

**Операции не равны факту обслуживания**: работу необходимо назначить, выполнить, доказать и при необходимости принять в порядке договора.

### 2.5. Resource / Evidence / Observation

```
Resource {id, organizationId, kind: plow | brush | grader | blower | loader | truck |
 crew | deicer | depot | snowSite,
 capacity?, compatibleOperations[], routeAccessRestrictions[],
 shiftCalendar[], startingLocation?, materialCapacity?, readinessStatus?,
 availabilityEvidence?, legalAvailabilityStatus}
Observation {id, observedAt, receivedAt, source, geoRefs[], parameter,
 value, unit, reliability, approvedForDeadlineClock: boolean,
 validForAssetIds[], evidenceId?}
Evidence {id, kind: gps | photo | weighTicket | receipt | inspectorAct |
              operatorLog | meteo | roadPatrol | workOrder | registryExtract,
 capturedAt, capturedByRole, source, confidence, hash?, associatedOperations[]}
Approval {id, operationPlanVersionId, approvedByRole, decision,
          approvedAt, scope, signatureReference?, remarks?}
```

Для водителей и работников использовать обезличенные идентификаторы в тестах, реальные персональные данные — только по утверждённой модели доступа и сроков хранения.

### 2.6. State machines

Раздельно:
- **Plan**: `draft → simulated → reviewed → approved → dispatched → amended/cancelled`.
- **Work operation**: `proposed → assigned → in_progress → machine_reported → inspector_verified → accepted/rejected/disputed`.
- **Road condition**: `unknown → observed_obstructed → planned → recovering → observed_serviceable → deteriorating`.

Отдельное состояние `reopened_by_new_snowfall`/новая работа для повторного накопления. GPS может переводить в `machine_reported`, но не напрямую в `accepted`.

## 3. Расчёт юридических сроков: только event-based

```
function evaluateRequirement(rule, asset, events, evidence) {
  if (!rule || rule.verificationStatus !== 'verified') return {state:'NEEDS_LEGAL_REVIEW'};
  if (!verifiedApplicability(rule, asset)) return {state:'NOT_VERIFIED_APPLICABLE'};
  const start = findAuthenticatedEvent(events, rule.clockStartEvent, asset);
  if (!start) return {state:'CLOCK_NOT_STARTED_OR_UNKNOWN'};
  const due = start.at + rule.clockDurationMinutes * 60 * 1000;
  const completed = findAcceptedCompletion(evidence, rule.completionEvidenceType, asset);
  if (!completed) return {state: Date.now()>due ? 'AT_RISK_POTENTIALLY_OVERDUE':'PENDING', due};
  return {state: completed.at<=due ? 'ONTIME_REPORTED':'LATE_REPORTED', due};
}
```

**Это псевдокод.** Даже с документами приложение не устанавливает административное правонарушение: юридическая квалификация требует проверки и уполномоченного решения. В условиях продолжающегося снегопада/нового события применимость ГОСТ и муниципальной нормы уточняется ответственным юристом/техслужбой. `Date.now()` в детерминированных тестах заменить передаваемым временем моделирования. Состояние `at risk` означает потенциальный риск, не доказанное нарушение.

## 4. Контрактная допустимость как жёсткий фильтр кандидатов

До оценки стоимости/времени:

```
canAssign(operation, resource, planContext) =
  identityAndAuthorityVerified(operation.assetId)
  AND assignedOrganizationAllowed(operation, resource.organizationId)
  AND contractActiveFor(operation, resource)
  AND workTypeIncluded(operation.workType)
  AND geographyIncluded(operation.assetId)
  AND resourceCompatible(operation, resource)
  AND shiftAndCrewAvailable(resource)
  AND roadAccessAndSafetyPermitted(operation, resource)
  AND specialSiteApprovedIfRequired(operation)
```

Если сведения отсутствуют: **в режиме VERIFIED DISPATCH — запрет и задача ручной валидации**; в режиме SANDBOX SIMULATION — условно разрешить с явным допущением и красной плашкой `ASSUMPTION`, а не «юридически допустимо».

### Примеры hard constraints

- Договор активен в момент выполнения, включает объект и конкретный вид работ, объем/лимит не превышен; исключения требуют отдельного одобрения.
- Опасный участок закрыт, имеет действующий приказ о запрете движения или режим противолавинных работ — техника не назначается без подтвержденного допуска.
- Самосвал с загрязнёнными снежными массами не разгружается на непроверенной площадке; если нет разрешённых площадок — выводить infeasible, не искать ближайший пустырь.
- Техника не может работать на проезде, если ширина/масса/радиус поворота/уклон не совместимы. При отсутствии точных габаритов — непроверенная совместимость.
- Не назначать работы «задним числом» и не создавать подписанный наряд алгоритмически.

## 5. Дополнительная геометрия и маршруты

Три разных графа:
1. **TrafficGraph**: разрешённые проезды техники, односторонность, манёвры/повороты, ограничения веса/высоты, закрытия, уклоны, временные окна, динамические скорости.
2. **ServiceGraph**: где и каким образом надо выполнить конкретную операцию (полоса, обе стороны, целая ширина, повторные проходы, переход, остановка, лестница, сток).
3. **AuthorityGraph** (логический, не дорожный): контракты, зоны ответственности, кто может выдать поручение и кто вправе принять.

Для `TrafficGraph` не переносить расстояния OSM напрямую как юридически разрешённый технологический манёвр, а работу на одном ребре не считать уборкой всех полос или сторон.

## 6. Математическая постановка для оптимизатора

Пусть $O$ — работы, $R$ — ресурсы, $E$ — реальные допустимые дорожные переходы; $x_{or}=1$, если работу $o$ делает ресурс $r$; $y_o=1$, если работа запланирована; $t_o$ — её начало, $c_o$ — окончание, $q_{o,r}$ — объём выполненной операции, $p_o$ — штраф за неудовлетворённый сервис.

База: $\sum_r x_{or}=y_o\le1$ для работ, выполняемых одной ресурсной группой; для погрузки/вывоза через несколько типов техники вводить отдельные ресурсы/операции, а не ошибочную «одна машина на всю работу». $x_{or}\le compatible_{or}\cdot authorized_{or}$, предшествование $t_j\ge c_i$ для $i\prec j$, ограничение доступности смены, окон движения, материала, приемной мощности, объемов и бюджета. Для нескольких циклов очистки один и тот же объект создает новые операции с собственными событием и сроком.

**Цель должна быть согласована с городом:** сперва безопасность/обязательные гарантии и доступность больниц, жителей, общественного транспорта; затем сервисно-взвешенное покрытие и сроки; потом стоимость, makespan, нерабочий пробег и выбросы. **Не** смешивать тысячи рублей с минутами без нормирования или явно согласованных денежных штрафов. Переключатель `economy`/`parallel` — упрощение, сохранить как UX-профили, но математическое определение и KPI задокументировать.

Для полноценных задач — иерархическая VRP/ARPP + pickup-delivery + resource-constrained project scheduling + periodic/rolling horizon. На малых тестах искать точный optimum или lower bound (CP-SAT/MILP), на масштабах использовать greedy insertion + relocate/swap + LNS, сравнивать Pareto/optimality gap. Изолировать ограничения от scoring: никакой оптимизатор не должен «улучшать» скорость незаконной отправкой техники.

### KPI муниципального заказчика и подрядчика отдельно

**Публичный результат:** время восстановления критического доступа, доля обеспеченных переходов/остановок, длина дорог в подтверждённом безопасном состоянии, просрочки по доказанным нормативным часам, число изолированных кварталов, повторное загрязнение.

**Исполнение:** наряды, фактическая техника, объёмы, отклонения план/факт, машино-часы, утилизация/снежные площадки, повторные выезды.

**Финансы:** прогноз затрат исполнителя, оцениваемая сумма по расценкам контракта, принятый объём и сумма, остатки лимита — четыре отдельные метрики. Не путать НМЦК закупки с расходами.

## 7. Интерфейс: три режима и маркировка истинности

- `SIMULATION`: допускает упрощения, видимые пользователю (виртуальные контракты, типовые сроки, приблизительные скорости); никогда не называет их юридически проверенными.
- `DISPATCH_DRAFT`: реальный оперативный проект — ещё не поручение; показывает «где не хватает сведений/утверждения».
- `VERIFIED_OPERATIONS`: только подтвержденные права, данные, сроки и уполномоченные утверждения; отдельный статус утвержденного диспетчерского плана.

Нужно отображать не только цвета маршрутов, а **слои юридических и физических объектов**: ведомство/заказчик, оператор/договор, допустимость назначения, плужная обработка, проходы/остановки, валы и вывоз, доступность, площадки и очереди, нормативные часы и источник (ГОСТ/170-нд/контракт/ЧС/демо), поле «неизвестно». Любое утверждение должно вести в source doc и событие.

## 8. Верификация: реалистичные стадии внедрения

### Unit-уровень
- Проверка RuleRegistry/версий/временных зон и событий начала часов.
- Контрактной допустимости: территория+вид работ+исполнитель+дата.
- State machine: GPS ≠ приёмка.
- Классификации road vs sidewalk vs courtyard vs facility.
- Невыполнимые задачи и handoff на согласование.

### Интеграция
- Сценарии из `04_ACCEPTANCE_SCENARIOS.json` переводить в тесты только после уточнения модели и интерфейсов; не подгонять доменную модель под формат имитационных входов.
- Ночные смены: переход через полночь, сезон, изменение редакции правил/договора, длительные циклоны, повторные уборки и открытие дороги после ЧС.
- Проверять качество данных и provenance при каждом импортном слое.

### Алгоритм
- Сохранить и запустить старые два контрпримера `tests/planner.audit.test.mjs`, не править ожидания; сравнить greedy, local search, LNS, маленькие exact instances.
- Стресс-тесты на 100/500/1000 работ: эксплицитный runtime budget, деградация, кеширование трансферов, incremental cost/schedule.
- Рабочее решение не должно содержать самообъявленного статуса "ГОСТ соблюден" без источников и юридического clock.

## 9. Политика данных и безопасности

- Персональные данные водителей, кадровые смены, GPS, номера телефонов, идентификаторы нарядов — разграничение доступа, правовое основание, срок хранения, аудит просмотров; для прототипа синтетические данные [S31].
- Закупочные суммы, остатки лимитов, оперативные схемы ограничений/ЧС и позиция техники — отдельные уровни доступа.
- Не объединять публичные, коммерческие и персональные наборы данных в одном общедоступном JSON.
- Вести версионирование входных данных, планов, решений и объяснений отказа; все команды и утверждения логировать.

## 10. Что именно делать с нынешним кодом

| Файл | Изменение | Приоритет |
|---|---|---|
| `backend/policy.mjs` | Преобразовать demo P1–P4 в явную стратегию; подгружать нормы из версионированного реестра | P0 |
| `backend/planner.mjs` | Выделить генератор кандидатов, constraints, scorer, постулучшение; новую матрицу совместимости и операций вводить постепенно | P1–P2 |
| `backend/service.mjs` | Валидация provenance и режима; версии нормативов, контрактов и разрешений; журнал решений | P0–P1 |
| `data/network.json` | Добавить внешнюю сопоставляемую таблицу дорожных объектов/подтверждений; НЕ переписывать OSM как «официальный реестр» | P0 |
| `public/map.js` | Отдельные слои факт/план/неизвестно, зона ответственности, операции и доказательства | P1 |
| `backend/planner.test.mjs` | Сохранить базовые тесты и добавить негативные тесты для назначения/юридических часов/приёмки | P0 |

**Архитектура для MVP:** параллельный `domain/` с типами/валидацией и новыми тестами + адаптер поверх существующего `plan()`; старый UI в режиме демо должен продолжать работать. Не проводить разрушительную «большую миграцию» за один проход Codex.
